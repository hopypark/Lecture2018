package com.example.research.motionsensor;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    // 중력
    TextView x_gravity;
    TextView y_gravity;
    TextView z_gravity;

    // 가속도
    TextView x_accelerometer;
    TextView y_accelerometer;
    TextView z_accelerometer;

    // 직선 가속도
    TextView x_linear_acceleration;
    TextView y_linear_acceleration;
    TextView z_linear_acceleration;

    // 자이로스코프
    TextView x_gyroscope;
    TextView y_gyroscope;
    TextView z_gyroscope;


    SensorManager sm;

    Sensor sensor_gravity;
    Sensor sensor_accelerometer;
    Sensor sensor_linear_acceleration;
    Sensor sensor_gyroscope;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        x_gravity = (TextView) findViewById(R.id.x_gravity);
        y_gravity = (TextView) findViewById(R.id.y_gravity);
        z_gravity = (TextView) findViewById(R.id.z_gravity);

        x_accelerometer = (TextView) findViewById(R.id.x_accelerometer);
        y_accelerometer = (TextView) findViewById(R.id.y_accelerometer);
        z_accelerometer = (TextView) findViewById(R.id.z_accelerometer);

        x_linear_acceleration = (TextView) findViewById(R.id.x_linear_acceleration);
        y_linear_acceleration = (TextView) findViewById(R.id.y_linear_acceleration);
        z_linear_acceleration = (TextView) findViewById(R.id.z_linear_acceleration);

        x_gyroscope = (TextView) findViewById(R.id.x_gyroscope);
        y_gyroscope = (TextView) findViewById(R.id.y_gyroscope);
        z_gyroscope = (TextView) findViewById(R.id.z_gyroscope);


        sm = (SensorManager) getSystemService(SENSOR_SERVICE);

        sensor_gravity = sm.getDefaultSensor(Sensor.TYPE_GRAVITY);
        sensor_accelerometer = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensor_linear_acceleration = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        sensor_gyroscope = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

    }

    @Override
    public void onSensorChanged(SensorEvent event) {

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
