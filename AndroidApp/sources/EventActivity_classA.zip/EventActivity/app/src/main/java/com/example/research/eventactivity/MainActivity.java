package com.example.research.eventactivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void displayPicture(View view){
        int vID = view.getId();

        TextView textView = (TextView) findViewById(vID);
        String title = (String) textView.getText();
        String tag = (String) textView.getTag();


        Intent it = new Intent(this, DetailViewActivity.class);
        it.putExtra("it_title", title);
        it.putExtra("it_tag", tag);
        startActivity(it);
    }
}
