import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ChatMessageS extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	JTextArea display;
	JLabel info;
	List<ServerThread> listThread;
	
	public ChatMessageS() {
		// creating the frame
		super("채팅프로그램-서버");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(800, 500);
		// info 
		info = new JLabel();		
		// TextArea
		display = new JTextArea();		
		display.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(display);
				
		getContentPane().add(BorderLayout.NORTH, info);
		getContentPane().add(BorderLayout.CENTER, scrollPane);
		setVisible(true);		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChatMessageS s = new ChatMessageS();
		s.runServer();
	}

	public void runServer() {
		ServerSocket server;
		Socket sock;
		ServerThread sThread;
		try {
			listThread = new ArrayList<ServerThread>();
			server = new ServerSocket(5000, 100);
			try {
				while(true) {
					sock = server.accept();
					sThread = new ServerThread(this, sock, display, info);
					sThread.start();
					info.setText(sock.getInetAddress().getHostName() + " 서버가 클라이언트와 연결됨");
				}
			
			}catch(IOException ioe) {
				server.close();
				ioe.printStackTrace();
			}
		}catch(IOException e) {
			
		}
	}
	
}


class ServerThread extends Thread{
	Socket sock;
	BufferedWriter output;
	BufferedReader input;
	JTextArea display;
	JLabel info;
	JTextField text;
	String clientdata;
	String serverdata="";
	ChatMessageS cs;
	
	private static final String SEPERATOR = "|";
	private static final int REQ_LOGIN = 1001;
	private static final int REQ_SENDWORDS = 1021;
	
	
	public ServerThread(ChatMessageS c, Socket s, JTextArea ta, JLabel l) {
		this.cs = c;
		this.sock = s;
		this.display = ta;
		this.info = l;
		
		try {
			input = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			output = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
		}catch(IOException ioe) {
			ioe.printStackTrace();
		}		
	}

	@Override
	public void run() {
		cs.listThread.add(this);
		
		try {
			while((clientdata = input.readLine()) != null ) {
				StringTokenizer st = new StringTokenizer(clientdata, SEPERATOR);
				int command = Integer.parseInt(st.nextToken());
				int cnt = cs.listThread.size();
				switch(command) {
					case REQ_LOGIN : { // "1001|아이디" 인 경우
						String ID = st.nextToken();
						display.append("아이디가 '"+ ID +"'인 클라이언트가 로그인 했습니다.\r\n");
						display.setCaretPosition(display.getDocument().getLength());
					}
					break;
					case REQ_SENDWORDS :{
						String ID = st.nextToken();
						String message = st.nextToken();
						display.append(ID + " : " + message + "\r\n");
						display.setCaretPosition(display.getDocument().getLength());
						
						for(int i=0 ; i<cnt ; i++) {
							ServerThread sThread = (ServerThread) cs.listThread.get(i);
							sThread.output.write(ID + " : " + message + "\r\n");
							sThread.output.flush();						
						}
					}
					break;
				} // switch
			}
		}catch(IOException ioe) {
			ioe.printStackTrace();
		}
		
		cs.listThread.remove(this);
		try {
			sock.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	} // run
	
}