import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ChatMessageC extends JFrame{

	private static final long serialVersionUID = 1L;
	
	JTextArea display;
	JTextField wtext, ltext;
	JLabel mlbl, wlbl, loglbl;
	
	BufferedWriter output;
	BufferedReader input;
	Socket client;
	StringBuffer clientdata;
	String serverdata;
	String ID;
	
	private static final String SEPERATOR = "|";
	private static final int REQ_LOGIN = 1001;
	private static final int REQ_SENDWORDS = 1021;
	
	public ChatMessageC() {
		// creating the frame
		super("채팅프로그램-클라이언트");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(600, 500);
		// info 
		mlbl = new JLabel("채팅 상태를 보여줍니다.");		
		getContentPane().add(BorderLayout.NORTH, mlbl);

		// TextArea
		display = new JTextArea();		
		display.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(display);
		
		getContentPane().add(BorderLayout.CENTER, scrollPane);

		// 대화말과 로그인
		JPanel plabel = new JPanel(new BorderLayout());
		// 대화말
		wlbl = new JLabel(" 대화말:  ");
		wtext = new JTextField(45); // 대화 입력 필드
		JPanel wpanel = new JPanel(new BorderLayout()); //		
		wpanel.add(wlbl, BorderLayout.WEST);
		wpanel.add(wtext, BorderLayout.EAST);
		//getContentPane().add(BorderLayout.CENTER, wpanel);
		plabel.add(wpanel, BorderLayout.CENTER);
		
		
		// 로그인 라벨과 입력
		JPanel ppanel = new JPanel(new BorderLayout());
		loglbl = new JLabel(" 로그온:  ");
		ltext = new JTextField(45); // 로그인 아이디 입력
		ltext.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (ID == null) {
					ID = ltext.getText();
					mlbl.setText( ID + "(으)로 로그인 하였습니다.");
					try {
						clientdata.setLength(0);
						clientdata.append(REQ_LOGIN).append(SEPERATOR).append(ID);
						output.write(clientdata.toString()+"\r\n");
						output.flush();
						ltext.setVisible(false);						
					}catch(Exception e) {
						e.printStackTrace();
					}
				}
			}			
		});
						
		ppanel.add(loglbl, BorderLayout.WEST);
		ppanel.add(ltext, BorderLayout.EAST);
		
		plabel.add(ppanel,BorderLayout.SOUTH);
		// 
		getContentPane().add(BorderLayout.SOUTH, plabel);
		
		// 대화 입력필드에서의 키보드 처리		
		wtext.addKeyListener(new KeyListener() {

			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar() == KeyEvent.VK_ENTER) {
					String message = new String();
					message = wtext.getText();
					
					if(ID == null) {
						mlbl.setText("다시 로그인 하세요!!!");
						wtext.setText("");
					}else {
						try {
							clientdata.setLength(0);
							clientdata.append(REQ_SENDWORDS).append(SEPERATOR).append(ID).append(SEPERATOR).append(message);
							output.write(clientdata.toString()+"\r\n");
							output.flush();
							wtext.setText("");
						}catch(IOException ex) {
							ex.printStackTrace();
						}
					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {}

			@Override
			public void keyTyped(KeyEvent e) {}
			
		});
		
		setVisible(true);				
	}
	
	public void runClient() {
		try {
			client = new Socket(InetAddress.getLocalHost(), 5000);
			mlbl.setText("연결된 서버 이름 : " + client.getInetAddress().getHostName());
			input = new BufferedReader(new InputStreamReader(client.getInputStream()));
			output = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
			clientdata = new StringBuffer(2048);
			mlbl.setText("접속 완료.  사용할 아이디를 입력하세요.");
			while(true) {
				serverdata = input.readLine();
				display.append(serverdata + "\r\n");
				display.setCaretPosition(display.getDocument().getLength());
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChatMessageC c = new ChatMessageC();
		c.runClient();
	}

}
