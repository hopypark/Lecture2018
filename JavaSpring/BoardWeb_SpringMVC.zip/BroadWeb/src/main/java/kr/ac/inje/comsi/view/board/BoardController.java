package kr.ac.inje.comsi.view.board;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import kr.ac.inje.comsi.board.BoardVO;
import kr.ac.inje.comsi.board.impl.BoardDAO;

@Controller
public class BoardController {

	// 글 목록 보기
	@RequestMapping(value="/getBoardList.do")
	public ModelAndView getBoardList(BoardVO vo, BoardDAO boardDAO, ModelAndView mav) {		
		
		mav.addObject("boardList", boardDAO.getBoardList(vo));
		mav.setViewName("getBoardList");
		return mav;
	}
	
	// 글 추가하기
	@RequestMapping(value="/insertBoard.do")
	public String insertBoard(BoardVO vo, BoardDAO boardDAO) {		
		boardDAO.insertBoard(vo);
		return "redirect:getBoardList.do";
	}
	
	// 글 수정하기
	@RequestMapping(value="/updateBoard.do")
	public String updateBoard(BoardVO vo, BoardDAO boardDAO	) {

		boardDAO.updateBoard(vo);
		
		return "redirect:getBoardList.do";		
	}	
	
	// 글 상세 보기
	@RequestMapping(value="/getBoard.do")
	public ModelAndView getBoard(BoardVO vo, BoardDAO boardDAO, ModelAndView mav) {
	
		mav.addObject("board", boardDAO.getBoard(vo));	// View 정보 저장
		mav.setViewName("getBoard");	// View wjdqh wjwkd
		return mav; // 
	}
	
	// 글 삭제
	@RequestMapping(value="/deleteBoard.do")
	public String deleteBoard(BoardVO vo, BoardDAO boardDAO) {
		
		boardDAO.deleteBoard(vo);
		return "redirect:getBoardList.do";
	}	
}
