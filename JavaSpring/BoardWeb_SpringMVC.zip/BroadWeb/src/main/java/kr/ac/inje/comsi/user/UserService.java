package kr.ac.inje.comsi.user;

public interface UserService {

	// CRUD 기능의 메소드
	// 회원 등록
	UserVO getUser(UserVO vo);

}