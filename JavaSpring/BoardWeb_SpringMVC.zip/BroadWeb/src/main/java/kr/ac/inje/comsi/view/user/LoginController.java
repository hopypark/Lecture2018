package kr.ac.inje.comsi.view.user;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.ac.inje.comsi.user.UserVO;
import kr.ac.inje.comsi.user.impl.UserDAO;

@Controller
public class LoginController{

	@RequestMapping("/login.do")
	public String login(UserVO vo, UserDAO userDAO) {		
		if (userDAO.getUser(vo) != null) return "redirect:getBoardList.do"; 
		else return "redirect:login.jsp";		
	}
}

