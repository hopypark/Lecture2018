package kr.ac.inje.comsi.board.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import kr.ac.inje.comsi.board.BoardVO;
import kr.ac.inje.comsi.common.JDBCUtil;

@Repository("boardDAO")
public class BoardDAO {
	// JDBC 관련 변수
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rset = null;
	
	// SQL 명령어
	private final String BOARD_INSERT = "insert into board(seq, title, writer, "
			+"content) values((select nvl(max(seq),0)+1 from board),?,?,?)";
	private final String BOARD_UPDATE = "update board set title=?, content=? where seq=?";
	private final String BOARD_DELETE = "delete board where seq=?";
	private final String BOARD_GET = "select * from board where seq=?";
	private final String BOARD_LIST = "select * from board order by seq desc";
	
	// CRUD 기능 구현 메소드
	/////////////////////////////////////////////////////////////////
	// 글 등록
	public void insertBoard(BoardVO vo) {
		System.out.println("==> JDBC로 insertBoard() 기능 처리");
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(BOARD_INSERT);
			pstmt.setString(1, vo.getTitle());
			pstmt.setString(2, vo.getWriter());
			pstmt.setString(3, vo.getContent());
			pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtil.close(pstmt, conn);
		}
	}
	
	// 글 수정
	public void updateBoard(BoardVO vo) {
		System.out.println("==> JDBC로 updateBoard() 기능 처리");
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(BOARD_UPDATE);
			pstmt.setString(1, vo.getTitle());
			pstmt.setString(2, vo.getContent());
			pstmt.setInt(3, vo.getSeq());
			pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtil.close(pstmt, conn);
		}
	}	
	
	// 글 삭제
	public void deleteBoard(BoardVO vo) {
		System.out.println("==> JDBC로 deleteBoard() 기능 처리");
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(BOARD_DELETE);
			pstmt.setInt(1, vo.getSeq());
			pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtil.close(pstmt, conn);
		}
	}	
	
	// 글 상세 조회
	public BoardVO getBoard(BoardVO vo) {
		System.out.println("==> JDBC로 getBoard() 기능 처리");
		BoardVO board = null;
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(BOARD_GET);
			pstmt.setInt(1,  vo.getSeq());
			rset = pstmt.executeQuery();
			if (rset.next()) {
				board = new BoardVO();
				board.setSeq(rset.getInt("SEQ"));
				board.setTitle(rset.getString("TITLE"));
				board.setWriter(rset.getString("WRITER"));
				board.setContent(rset.getString("CONTENT"));
				board.setRegDate(rset.getDate("REGDATE"));
				board.setCnt(rset.getInt("CNT"));
			}			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtil.close(rset, pstmt, conn);
		}
		return board;		
	}	
	
	// 글 목록 조회
	public List<BoardVO> getBoardList(BoardVO vo) {
		System.out.println("==> JDBC로 getBoardList() 기능 처리");
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(BOARD_LIST);
			rset = pstmt.executeQuery();
			while (rset.next()) {
				BoardVO board = new BoardVO();
				board.setSeq(rset.getInt("SEQ"));
				board.setTitle(rset.getString("TITLE"));
				board.setWriter(rset.getString("WRITER"));
				board.setContent(rset.getString("CONTENT"));
				board.setRegDate(rset.getDate("REGDATE"));
				board.setCnt(rset.getInt("CNT"));
				boardList.add(board);				
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtil.close(rset, pstmt, conn);
		}
		return boardList;
	}		
}
