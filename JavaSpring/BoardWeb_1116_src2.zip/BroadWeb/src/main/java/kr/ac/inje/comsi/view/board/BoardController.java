package kr.ac.inje.comsi.view.board;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import kr.ac.inje.comsi.board.BoardService;
import kr.ac.inje.comsi.board.BoardVO;

@Controller
@SessionAttributes("board")
public class BoardController {
	
	@Autowired
	private BoardService boardService;

	// 글 목록 보기
	@RequestMapping(value="/getBoardList.do")
	public ModelAndView getBoardList(BoardVO vo, ModelAndView mav) {		
		
		mav.addObject("boardList", boardService.getBoardList(vo));
		mav.setViewName("getBoardList");
		return mav;
	}
	
	// 글 추가하기
	@RequestMapping(value="/insertBoard.do")
	public String insertBoard(BoardVO vo) {		
		boardService.insertBoard(vo);
		return "redirect:getBoardList.do";
	}
	
	// 글 수정하기
	@RequestMapping(value="/updateBoard.do")
	public String updateBoard(BoardVO vo) {
		boardService.updateBoard(vo);
		
		return "redirect:getBoardList.do";		
	}	
	
	// 글 상세 보기
	@RequestMapping(value="/getBoard.do")
	public String getBoard(BoardVO vo, Model model) {
		System.out.println("Model과 @SessionAttributes 적용");
		model.addAttribute("board", boardService.getBoard(vo));
		return "getBoard";  
	}
	
	// 글 삭제
	@RequestMapping(value="/deleteBoard.do")
	public String deleteBoard(BoardVO vo) {
		
		boardService.deleteBoard(vo);
		return "redirect:getBoardList.do";
	}	
}
